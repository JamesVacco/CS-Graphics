public class point
{
	double x,y,z;

	public point (double ix, double iy,  double iz)
	{
		this.x = ix;
		this.y = iy;
		this.z = iz;
	}
}
